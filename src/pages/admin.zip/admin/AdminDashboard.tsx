import { Link } from "react-router-dom";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Newspaper,
  FileText,
  CheckCircle2,
  PenLine,
  Plus,
  Clock,
  ArrowRight,
  FolderOpen,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

function StatCard({
  label,
  value,
  icon: Icon,
  accent,
  isLoading,
}: {
  label: string;
  value: number | undefined;
  icon: React.ElementType;
  accent: string;
  isLoading: boolean;
}) {
  return (
    <div
      className="rounded-2xl p-6 flex items-center gap-5 shadow-sm transition-transform hover:-translate-y-0.5 hover:shadow-md"
      style={{ background: "#ffffff", border: "1px solid #e5e0d8" }}
    >
      <div
        className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${accent}18` }}
      >
        <Icon className="w-7 h-7" style={{ color: accent }} />
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wide" style={{ color: "#8a8070" }}>
          {label}
        </p>
        {isLoading ? (
          <Skeleton className="h-8 w-16 mt-1" style={{ background: "#e5e0d8" }} />
        ) : (
          <p
            className="text-3xl font-bold mt-0.5"
            style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
          >
            {value ?? 0}
          </p>
        )}
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const { data: allPosts, isLoading: loadingAll } = trpc.blog.postList.useQuery({});
  const { data: published, isLoading: loadingPub } = trpc.blog.postList.useQuery({
    status: "published",
    limit: 100,
  });
  const { data: drafts, isLoading: loadingDraft } = trpc.blog.postList.useQuery({
    status: "draft",
    limit: 100,
  });
  const { data: categories, isLoading: loadingCats } = trpc.blog.categoryList.useQuery();

  const recentPosts = allPosts?.posts?.slice(0, 5) ?? [];
  const isLoading = loadingAll || loadingPub || loadingDraft || loadingCats;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            className="text-2xl font-bold"
            style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
          >
            Dashboard
          </h1>
          <p className="text-sm mt-1" style={{ color: "#8a8070" }}>
            Resumen del contenido del sitio web
          </p>
        </div>
        <Button
          asChild
          className="text-white gap-2 font-semibold shadow-md hover:opacity-90 transition-opacity"
          style={{ background: "linear-gradient(135deg, #C8102E, #a00d24)" }}
        >
          <Link to="/admin/posts/new">
            <Plus className="w-4 h-4" />
            Nueva noticia
          </Link>
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total noticias"
          value={allPosts?.pagination?.total}
          icon={Newspaper}
          accent="#1E3A5F"
          isLoading={loadingAll}
        />
        <StatCard
          label="Publicadas"
          value={published?.pagination?.total}
          icon={CheckCircle2}
          accent="#2e7d32"
          isLoading={loadingPub}
        />
        <StatCard
          label="Borradores"
          value={drafts?.pagination?.total}
          icon={PenLine}
          accent="#E8B830"
          isLoading={loadingDraft}
        />
        <StatCard
          label="Categorías"
          value={categories?.length}
          icon={FolderOpen}
          accent="#C8102E"
          isLoading={loadingCats}
        />
      </div>

      {/* Recent posts */}
      <div
        className="rounded-2xl shadow-sm overflow-hidden"
        style={{ background: "#ffffff", border: "1px solid #e5e0d8" }}
      >
        {/* Card header */}
        <div
          className="flex items-center justify-between px-6 py-5"
          style={{ borderBottom: "2px solid #E8B830" }}
        >
          <h2
            className="text-base font-bold flex items-center gap-2"
            style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
          >
            <Newspaper className="w-4 h-4" style={{ color: "#C8102E" }} />
            Noticias recientes
          </h2>
          <Button
            asChild
            variant="ghost"
            size="sm"
            className="gap-1 text-sm font-medium hover:bg-transparent"
            style={{ color: "#C8102E" }}
          >
            <Link to="/admin/posts">
              Ver todas
              <ArrowRight className="w-3 h-3" />
            </Link>
          </Button>
        </div>

        {/* Posts list */}
        {isLoading ? (
          <div className="divide-y" style={{ borderColor: "#f0ece4" }}>
            {[...Array(4)].map((_, i) => (
              <div key={i} className="px-6 py-4 flex items-center gap-4">
                <Skeleton className="h-4 w-4/5" style={{ background: "#e5e0d8" }} />
                <Skeleton className="h-5 w-16 ml-auto" style={{ background: "#e5e0d8" }} />
              </div>
            ))}
          </div>
        ) : recentPosts.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <div
              className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
              style={{ background: "#f5f3ef" }}
            >
              <Newspaper className="w-8 h-8" style={{ color: "#c4bdb0" }} />
            </div>
            <p className="text-sm font-medium" style={{ color: "#8a8070" }}>
              No hay noticias aún.
            </p>
            <Button
              asChild
              size="sm"
              className="mt-4 text-white gap-1"
              style={{ background: "#1E3A5F" }}
            >
              <Link to="/admin/posts/new">
                <Plus className="w-3 h-3" /> Crear primera noticia
              </Link>
            </Button>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "#f0ece4" }}>
            {recentPosts.map((post) => (
              <Link
                key={post.id}
                to={`/admin/posts/${post.id}/edit`}
                className="flex items-center gap-4 px-6 py-4 transition-colors group"
                style={{ color: "inherit" }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "#faf8f5";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "transparent";
                }}
              >
                {/* Left accent */}
                <div
                  className="w-1 h-8 rounded-full flex-shrink-0 transition-all group-hover:h-10"
                  style={{
                    background:
                      post.status === "published"
                        ? "linear-gradient(180deg, #2e7d32, #4caf50)"
                        : "linear-gradient(180deg, #E8B830, #f5d020)",
                  }}
                />

                <div className="flex-1 min-w-0">
                  <p
                    className="text-sm font-semibold truncate transition-colors"
                    style={{ color: "#1E3A5F" }}
                  >
                    {post.title}
                  </p>
                  <p className="text-xs mt-0.5 flex items-center gap-1" style={{ color: "#8a8070" }}>
                    <Clock className="w-3 h-3" />
                    {format(new Date(post.createdAt), "d MMM yyyy", { locale: es })}
                  </p>
                </div>

                <span
                  className="text-xs font-medium px-2.5 py-1 rounded-full flex-shrink-0"
                  style={
                    post.status === "published"
                      ? { background: "rgba(46,125,50,0.1)", color: "#2e7d32" }
                      : { background: "rgba(232,184,48,0.15)", color: "#b8920a" }
                  }
                >
                  {post.status === "published" ? "Publicado" : "Borrador"}
                </span>

                <ArrowRight
                  className="w-4 h-4 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ color: "#C8102E" }}
                />
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          {
            to: "/admin/posts/new",
            icon: Plus,
            label: "Nueva noticia",
            desc: "Redactar y publicar una noticia",
            accent: "#C8102E",
          },
          {
            to: "/admin/posts?status=draft",
            icon: FileText,
            label: "Borradores",
            desc: "Retomar notas sin publicar",
            accent: "#E8B830",
          },
          {
            to: "/admin/posts?status=published",
            icon: CheckCircle2,
            label: "Publicadas",
            desc: "Ver noticias en el sitio",
            accent: "#2e7d32",
          },
        ].map((action) => (
          <Link
            key={action.to}
            to={action.to}
            className="group rounded-2xl p-5 flex items-center gap-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            style={{ background: "#ffffff", border: "1px solid #e5e0d8" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor = action.accent + "60";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor = "#e5e0d8";
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${action.accent}15` }}
            >
              <action.icon className="w-5 h-5" style={{ color: action.accent }} />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold" style={{ color: "#1E3A5F" }}>
                {action.label}
              </p>
              <p className="text-xs" style={{ color: "#8a8070" }}>
                {action.desc}
              </p>
            </div>
            <ArrowRight
              className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
              style={{ color: action.accent }}
            />
          </Link>
        ))}
      </div>
    </div>
  );
}
