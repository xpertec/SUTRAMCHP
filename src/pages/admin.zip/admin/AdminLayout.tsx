import { useEffect } from "react";
import { Link, useLocation, useNavigate, Outlet, Navigate } from "react-router-dom";
import { LOGIN_PATH } from "@/const";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  LayoutDashboard,
  LogOut,
  ChevronRight,
  Newspaper,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const navItems = [
  {
    href: "/admin",
    label: "Dashboard",
    icon: LayoutDashboard,
    exact: true,
  },
  {
    href: "/admin/posts",
    label: "Noticias",
    icon: Newspaper,
  },
];

export default function AdminLayout() {
  const { user, isLoading, isAuthenticated, logout } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (!isLoading && isAuthenticated && user?.role !== "admin") {
      navigate("/", { replace: true });
    }
  }, [isLoading, isAuthenticated, user, navigate]);

  if (isLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "#1E3A5F" }}
      >
        <div className="flex flex-col items-center gap-4">
          <div
            className="w-14 h-14 rounded-full border-4 border-t-transparent animate-spin"
            style={{ borderColor: "#E8B830", borderTopColor: "transparent" }}
          />
          <p className="text-sm" style={{ color: "rgba(232,184,48,0.7)" }}>
            Verificando acceso...
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to={LOGIN_PATH} replace />;
  }

  if (user?.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  const initials = user.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "AD";

  return (
    <div className="min-h-screen flex" style={{ background: "#F5F3EF" }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 flex flex-col transition-transform duration-300 ease-in-out shadow-2xl",
          "lg:translate-x-0 lg:static lg:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
        style={{ background: "linear-gradient(180deg, #1E3A5F 0%, #162d4a 100%)" }}
      >
        {/* Logo */}
        <div
          className="flex items-center gap-3 px-5 py-5"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}
        >
          <div
            className="w-10 h-10 rounded-full p-0.5 flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #E8B830, #C8102E)" }}
          >
            <img
              src="/images/logo.jpeg"
              alt="SUTRAMCHP"
              className="w-full h-full rounded-full object-cover border-2 border-white"
            />
          </div>
          <div className="min-w-0 flex-1">
            <p
              className="text-sm font-bold text-white truncate"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              SUTRAMCHP
            </p>
            <p className="text-xs" style={{ color: "rgba(232,184,48,0.8)" }}>
              Panel CMS
            </p>
          </div>
          <button
            className="ml-auto lg:hidden text-white/50 hover:text-white transition-colors"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-5 space-y-1">
          {navItems.map((item) => {
            const isActive = item.exact
              ? location.pathname === item.href
              : location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setSidebarOpen(false)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group"
                style={
                  isActive
                    ? {
                        background: "rgba(200,16,46,0.25)",
                        color: "#ffffff",
                        borderLeft: "3px solid #C8102E",
                      }
                    : {
                        color: "rgba(255,255,255,0.6)",
                        borderLeft: "3px solid transparent",
                      }
                }
                onMouseEnter={(e) => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background =
                      "rgba(255,255,255,0.07)";
                    (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.9)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                    (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.6)";
                  }
                }}
              >
                <item.icon
                  className="w-4 h-4 flex-shrink-0"
                  style={{ color: isActive ? "#E8B830" : "inherit" }}
                />
                {item.label}
                {isActive && (
                  <ChevronRight
                    className="w-3 h-3 ml-auto"
                    style={{ color: "#E8B830" }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Divider */}
        <div style={{ height: "1px", background: "rgba(255,255,255,0.08)", margin: "0 16px" }} />

        {/* User info */}
        <div className="p-4">
          <div
            className="flex items-center gap-3 p-3 rounded-xl"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <Avatar className="w-8 h-8 flex-shrink-0">
              <AvatarImage src={user.avatar ?? undefined} />
              <AvatarFallback
                className="text-white text-xs font-bold"
                style={{ background: "linear-gradient(135deg, #C8102E, #a00d24)" }}
              >
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-white truncate">
                {user.name ?? user.email}
              </p>
              <span
                className="text-[10px] font-medium px-1.5 py-0.5 rounded-full"
                style={{ background: "rgba(232,184,48,0.2)", color: "#E8B830" }}
              >
                Admin
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="w-7 h-7 flex-shrink-0 transition-colors"
              style={{ color: "rgba(255,255,255,0.4)" }}
              onClick={() => logout()}
              title="Cerrar sesión"
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color = "#C8102E";
                (e.currentTarget as HTMLElement).style.background = "rgba(200,16,46,0.15)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.4)";
                (e.currentTarget as HTMLElement).style.background = "transparent";
              }}
            >
              <LogOut className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar (mobile) */}
        <header
          className="lg:hidden flex items-center gap-4 px-4 py-3 shadow-sm"
          style={{
            background: "#1E3A5F",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <button
            className="text-white/60 hover:text-white transition-colors"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-full p-0.5"
              style={{ background: "linear-gradient(135deg, #E8B830, #C8102E)" }}
            >
              <img
                src="/images/logo.jpeg"
                alt="SUTRAMCHP"
                className="w-full h-full rounded-full object-cover border border-white"
              />
            </div>
            <span
              className="text-sm font-bold text-white"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              SUTRAMCHP CMS
            </span>
          </div>
        </header>

        {/* Top bar (desktop) */}
        <header
          className="hidden lg:flex items-center justify-between px-8 py-4 shadow-sm"
          style={{
            background: "#ffffff",
            borderBottom: "2px solid #E8B830",
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-1 h-6 rounded-full"
              style={{ background: "linear-gradient(180deg, #C8102E, #E8B830)" }}
            />
            <span className="text-sm font-medium" style={{ color: "#1E3A5F" }}>
              {navItems.find((n) =>
                n.exact
                  ? location.pathname === n.href
                  : location.pathname.startsWith(n.href)
              )?.label ?? "Panel CMS"}
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs" style={{ color: "#1E3A5F" }}>
            <span>Conectado como</span>
            <strong>{user.name ?? user.email}</strong>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
