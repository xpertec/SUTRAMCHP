import { useEffect, useState, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";


import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Save,
  ArrowLeft,
  Globe,
  FileText,
  Tag,
  Image as ImageIcon,
  Info,
  CheckCircle2,
  Upload,
  Trash2,
  Link as LinkIcon,
  FileImage,
} from "lucide-react";
import { toast } from "sonner";

const postSchema = z.object({
  title: z.string().min(1, "El título es obligatorio"),
  slug: z.string().min(1, "El slug es obligatorio"),
  content: z.string().min(1, "El contenido es obligatorio"),
  excerpt: z.string().optional(),
  featuredImage: z.string().optional(),
  categoryId: z.string().optional(),
  status: z.enum(["draft", "published"]),
  metaTitle: z.string().optional(),
  metaDescription: z.string().optional(),
  tagIds: z.array(z.number()).optional(),
});

type PostFormData = z.infer<typeof postSchema>;

function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

function FormSection({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-2xl p-6 space-y-4 shadow-sm"
      style={{ background: "#ffffff", border: "1px solid #e5e0d8" }}
    >
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4" style={{ color: "#C8102E" }} />
        <h2
          className="text-sm font-semibold"
          style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
        >
          {title}
        </h2>
      </div>
      <Separator style={{ background: "#e5e0d8" }} />
      {children}
    </div>
  );
}

export default function AdminPostForm() {
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imageInputMode, setImageInputMode] = useState<"file" | "url">("file");
  const [fileName, setFileName] = useState<string | null>(null);

  const { data: post, isLoading: loadingPost } = trpc.blog.postById.useQuery(
    { id: Number(id) },
    { enabled: isEditing }
  );
  const { data: categories } = trpc.blog.categoryList.useQuery();
  const { data: tags } = trpc.blog.tagList.useQuery();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    control,
    formState: { errors },
  } = useForm<PostFormData>({
    resolver: zodResolver(postSchema),
    defaultValues: {
      title: "",
      slug: "",
      content: "",
      excerpt: "",
      featuredImage: "",
      categoryId: "",
      status: "draft",
      metaTitle: "",
      metaDescription: "",
      tagIds: [],
    },
  });

  // Populate form when editing
  useEffect(() => {
    if (post) {
      setValue("title", post.title);
      setValue("slug", post.slug);
      setValue("content", post.content);
      setValue("excerpt", post.excerpt ?? "");
      setValue("featuredImage", post.featuredImage ?? "");
      setValue("categoryId", post.categoryId ? String(post.categoryId) : "");
      setValue("status", post.status);
      setValue("metaTitle", post.metaTitle ?? "");
      setValue("metaDescription", post.metaDescription ?? "");
      if (post.featuredImage) {
        if (post.featuredImage.startsWith("data:")) {
          setImageInputMode("file");
          setFileName("Imagen cargada");
        } else {
          setImageInputMode("url");
        }
      }
    }
  }, [post, setValue]);

  // Auto-generate slug from title (only on create)
  const title = watch("title");
  useEffect(() => {
    if (!isEditing) {
      setValue("slug", slugify(title));
    }
  }, [title, isEditing, setValue]);

  const createMutation = trpc.blog.postCreate.useMutation({
    onSuccess: () => {
      utils.blog.postList.invalidate();
      toast.success("Noticia creada exitosamente");
      navigate("/admin/posts");
    },
    onError: (err) => {
      toast.error(err.message || "Error al crear la noticia");
    },
  });

  const updateMutation = trpc.blog.postUpdate.useMutation({
    onSuccess: () => {
      utils.blog.postList.invalidate();
      if (id) utils.blog.postById.invalidate({ id: Number(id) });
      toast.success("Noticia actualizada exitosamente");
      navigate("/admin/posts");
    },
    onError: (err) => {
      toast.error(err.message || "Error al actualizar la noticia");
    },
  });

  const isPending = createMutation.isPending || updateMutation.isPending;

  const onSubmit = (data: PostFormData) => {
    const payload = {
      title: data.title,
      slug: data.slug,
      content: data.content,
      excerpt: data.excerpt || undefined,
      featuredImage: data.featuredImage || undefined,
      categoryId: data.categoryId ? Number(data.categoryId) : undefined,
      status: data.status,
      metaTitle: data.metaTitle || undefined,
      metaDescription: data.metaDescription || undefined,
      tagIds: data.tagIds ?? [],
    };

    if (isEditing) {
      updateMutation.mutate({ id: Number(id), ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const [isDragging, setIsDragging] = useState(false);

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Por favor selecciona un archivo de imagen válido (PNG, JPG, WEBP, GIF)");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error("La imagen no debe superar los 10MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setValue("featuredImage", result);
        setFileName(file.name);
        toast.success(`Imagen "${file.name}" cargada localmente`);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleRemoveImage = () => {
    setValue("featuredImage", "");
    setFileName(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const selectedTagIds = watch("tagIds") ?? [];
  const featuredImageValue = watch("featuredImage");

  const toggleTag = (tagId: number) => {
    const current = selectedTagIds;
    if (current.includes(tagId)) {
      setValue("tagIds", current.filter((t) => t !== tagId));
    } else {
      setValue("tagIds", [...current, tagId]);
    }
  };

  if (isEditing && loadingPost) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48 rounded-xl" style={{ background: "#e5e0d8" }} />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="h-64 w-full rounded-2xl" style={{ background: "#e5e0d8" }} />
            <Skeleton className="h-48 w-full rounded-2xl" style={{ background: "#e5e0d8" }} />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-40 w-full rounded-2xl" style={{ background: "#e5e0d8" }} />
            <Skeleton className="h-32 w-full rounded-2xl" style={{ background: "#e5e0d8" }} />
          </div>
        </div>
      </div>
    );
  }

  const currentStatus = watch("status");

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="w-8 h-8 transition-colors"
            style={{ color: "#1E3A5F", background: "rgba(30,58,95,0.08)" }}
            onClick={() => navigate("/admin/posts")}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1
              className="text-xl font-bold"
              style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
            >
              {isEditing ? "Editar noticia" : "Nueva noticia"}
            </h1>
            <p className="text-xs mt-0.5" style={{ color: "#8a8070" }}>
              {isEditing ? `Editando: ${post?.title}` : "Completa los campos para publicar"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="text-xs font-medium px-2.5 py-1 rounded-full inline-flex items-center gap-1"
            style={
              currentStatus === "published"
                ? { background: "rgba(46,125,50,0.1)", color: "#2e7d32" }
                : { background: "rgba(232,184,48,0.15)", color: "#b8920a" }
            }
          >
            {currentStatus === "published" ? (
              <><Globe className="w-3 h-3" />Publicado</>
            ) : (
              <><FileText className="w-3 h-3" />Borrador</>
            )}
          </span>
          <Button
            type="submit"
            disabled={isPending}
            className="text-white gap-2 font-semibold hover:opacity-90"
            style={{ background: "linear-gradient(135deg, #C8102E, #a00d24)" }}
          >
            {isPending ? (
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {isPending ? "Guardando..." : "Guardar"}
          </Button>
        </div>
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column (main content) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Content */}
          <FormSection icon={FileText} title="Contenido principal">
            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>
                Título <span style={{ color: "#C8102E" }}>*</span>
              </Label>
              <Input
                {...register("title")}
                placeholder="Escribe el título de la noticia..."
                className="border"
                style={{
                  background: "#faf8f5",
                  borderColor: "#ddd8d0",
                  color: "#1E3A5F",
                }}
              />
              {errors.title && (
                <p className="text-xs" style={{ color: "#C8102E" }}>{errors.title.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Slug (URL)</Label>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium" style={{ color: "#8a8070" }}>/blog/</span>
                <Input
                  {...register("slug")}
                  placeholder="url-de-la-noticia"
                  className="border"
                  style={{
                    background: "#faf8f5",
                    borderColor: "#ddd8d0",
                    color: "#1E3A5F",
                  }}
                />
              </div>
              {errors.slug && (
                <p className="text-xs" style={{ color: "#C8102E" }}>{errors.slug.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>
                Contenido <span style={{ color: "#C8102E" }}>*</span>
              </Label>
              <Textarea
                {...register("content")}
                placeholder="Escribe el contenido completo de la noticia..."
                rows={14}
                className="border resize-none font-mono text-sm leading-relaxed"
                style={{
                  background: "#faf8f5",
                  borderColor: "#ddd8d0",
                  color: "#1E3A5F",
                }}
              />
              {errors.content && (
                <p className="text-xs" style={{ color: "#C8102E" }}>{errors.content.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Extracto / Resumen</Label>
              <Textarea
                {...register("excerpt")}
                placeholder="Breve descripción que aparece en la lista de noticias..."
                rows={3}
                className="border resize-none"
                style={{
                  background: "#faf8f5",
                  borderColor: "#ddd8d0",
                  color: "#1E3A5F",
                }}
              />
            </div>
          </FormSection>

          {/* SEO */}
          <FormSection icon={Info} title="SEO (opcional)">
            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Meta título</Label>
              <Input
                {...register("metaTitle")}
                placeholder="Título para buscadores (por defecto se usa el título principal)"
                className="border"
                style={{ background: "#faf8f5", borderColor: "#ddd8d0", color: "#1E3A5F" }}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Meta descripción</Label>
              <Textarea
                {...register("metaDescription")}
                placeholder="Descripción para buscadores (máx. 160 caracteres recomendados)"
                rows={2}
                className="border resize-none"
                style={{ background: "#faf8f5", borderColor: "#ddd8d0", color: "#1E3A5F" }}
              />
            </div>
          </FormSection>
        </div>

        {/* Right column (settings) */}
        <div className="space-y-6">
          {/* Publish settings */}
          <FormSection icon={Globe} title="Publicación">
            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Estado</Label>
              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger
                      className="border"
                      style={{ background: "#faf8f5", borderColor: "#ddd8d0", color: "#1E3A5F" }}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent style={{ background: "#ffffff", border: "1px solid #ddd8d0" }}>
                      <SelectItem value="draft" style={{ color: "#1E3A5F" }}>
                        <span className="flex items-center gap-2">
                          <FileText className="w-3.5 h-3.5" style={{ color: "#E8B830" }} />
                          Borrador
                        </span>
                      </SelectItem>
                      <SelectItem value="published" style={{ color: "#1E3A5F" }}>
                        <span className="flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5" style={{ color: "#2e7d32" }} />
                          Publicado
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium" style={{ color: "#1E3A5F" }}>Categoría</Label>
              <Controller
                control={control}
                name="categoryId"
                render={({ field }) => (
                  <Select
                    value={field.value || "none"}
                    onValueChange={(val) => field.onChange(val === "none" ? "" : val)}
                  >
                    <SelectTrigger
                      className="border"
                      style={{ background: "#faf8f5", borderColor: "#ddd8d0", color: "#1E3A5F" }}
                    >
                      <SelectValue placeholder="Sin categoría" />
                    </SelectTrigger>
                    <SelectContent style={{ background: "#ffffff", border: "1px solid #ddd8d0" }}>
                      <SelectItem value="none" style={{ color: "#8a8070" }}>
                        Sin categoría
                      </SelectItem>
                      {categories?.map((cat) => (
                        <SelectItem
                          key={cat.id}
                          value={String(cat.id)}
                          style={{ color: "#1E3A5F" }}
                        >
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
          </FormSection>

          {/* Featured image with local upload */}
          <FormSection icon={ImageIcon} title="Imagen destacada">
            {/* Mode Selector */}
            <div
              className="flex gap-1 p-1 rounded-lg text-xs"
              style={{ background: "#f0ece4" }}
            >
              <button
                type="button"
                onClick={() => setImageInputMode("file")}
                className="flex-1 py-1.5 px-3 rounded-md font-medium transition-all flex items-center justify-center gap-1.5"
                style={
                  imageInputMode === "file"
                    ? { background: "#1E3A5F", color: "#ffffff", boxShadow: "0 2px 8px rgba(30,58,95,0.3)" }
                    : { color: "#8a8070" }
                }
              >
                <Upload className="w-3.5 h-3.5" />
                Subir local
              </button>
              <button
                type="button"
                onClick={() => setImageInputMode("url")}
                className="flex-1 py-1.5 px-3 rounded-md font-medium transition-all flex items-center justify-center gap-1.5"
                style={
                  imageInputMode === "url"
                    ? { background: "#1E3A5F", color: "#ffffff", boxShadow: "0 2px 8px rgba(30,58,95,0.3)" }
                    : { color: "#8a8070" }
                }
              >
                <LinkIcon className="w-3.5 h-3.5" />
                URL externa
              </button>
            </div>

            {imageInputMode === "file" ? (
              <div className="space-y-3">
                <input
                  ref={fileInputRef}
                  id="featured-image-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="sr-only"
                />
                <label
                  htmlFor="featured-image-upload"
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className="flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-5 cursor-pointer transition-all text-center group select-none"
                  style={{
                    borderColor: isDragging ? "#C8102E" : "#ddd8d0",
                    background: isDragging ? "rgba(200,16,46,0.05)" : "#faf8f5",
                    transform: isDragging ? "scale(1.01)" : "scale(1)",
                  }}
                >
                  <FileImage
                    className="w-8 h-8 group-hover:scale-110 transition-transform mb-2 pointer-events-none"
                    style={{ color: "#1E3A5F" }}
                  />
                  <p
                    className="text-xs font-semibold pointer-events-none"
                    style={{ color: "#1E3A5F" }}
                  >
                    {fileName ? fileName : "Haz clic aquí o arrastra una imagen"}
                  </p>
                  <p
                    className="text-[11px] mt-1 pointer-events-none"
                    style={{ color: "#8a8070" }}
                  >
                    PNG, JPG, WEBP, GIF hasta 10MB
                  </p>
                  <span
                    className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-1.5 text-white rounded-lg text-xs font-medium transition-all pointer-events-none"
                    style={{ background: "#1E3A5F", boxShadow: "0 2px 8px rgba(30,58,95,0.3)" }}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Seleccionar archivo
                  </span>
                </label>
              </div>
            ) : (
              <div className="space-y-2">
                <Label className="text-xs font-medium" style={{ color: "#1E3A5F" }}>URL de la imagen</Label>
                <Input
                  {...register("featuredImage")}
                  placeholder="https://ejemplo.com/imagen.jpg"
                  className="border text-xs"
                  style={{ background: "#faf8f5", borderColor: "#ddd8d0", color: "#1E3A5F" }}
                />
              </div>
            )}

            {/* Image Preview & Delete */}
            {featuredImageValue && (
              <div className="space-y-2 pt-1">
                <div
                  className="relative rounded-xl overflow-hidden group"
                  style={{ border: "1px solid #ddd8d0" }}
                >
                  <img
                    src={featuredImageValue}
                    alt="Preview"
                    className="w-full h-36 object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={handleRemoveImage}
                      className="text-white h-8 text-xs gap-1 font-semibold"
                      style={{ background: "#C8102E" }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Eliminar imagen
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </FormSection>

          {/* Tags */}
          {tags && tags.length > 0 && (
            <FormSection icon={Tag} title="Etiquetas">
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => {
                  const isSelected = selectedTagIds.includes(tag.id);
                  return (
                    <button
                      key={tag.id}
                      type="button"
                      onClick={() => toggleTag(tag.id)}
                      className="px-2.5 py-1 rounded-full text-xs font-medium border transition-all"
                      style={
                        isSelected
                          ? {
                              background: "rgba(200,16,46,0.12)",
                              borderColor: "rgba(200,16,46,0.4)",
                              color: "#C8102E",
                            }
                          : {
                              background: "#faf8f5",
                              borderColor: "#ddd8d0",
                              color: "#8a8070",
                            }
                      }
                    >
                      {isSelected && <CheckCircle2 className="w-2.5 h-2.5 inline mr-1" />}
                      {tag.name}
                    </button>
                  );
                })}
              </div>
            </FormSection>
          )}
        </div>
      </div>
    </form>
  );
}
