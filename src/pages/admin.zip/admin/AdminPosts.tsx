import { useState } from "react";
import { Link } from "react-router-dom";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Newspaper,
  ChevronLeft,
  ChevronRight,
  Globe,
  FileText,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { toast } from "sonner";

export default function AdminPosts() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage] = useState(1);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const queryInput = {
    page,
    limit: 10,
    ...(statusFilter !== "all" ? { status: statusFilter } : {}),
    ...(search ? { search } : {}),
  };

  const { data, isLoading } = trpc.blog.postList.useQuery(queryInput);
  const { data: categories } = trpc.blog.categoryList.useQuery();

  const deleteMutation = trpc.blog.postDelete.useMutation({
    onSuccess: () => {
      utils.blog.postList.invalidate();
      setDeleteId(null);
      toast.success("Noticia eliminada correctamente");
    },
    onError: () => {
      toast.error("Error al eliminar la noticia");
    },
  });

  const posts = data?.posts ?? [];
  const pagination = data?.pagination;

  const getCategoryName = (categoryId: number | null | undefined) => {
    if (!categoryId) return null;
    return categories?.find((c) => c.id === categoryId)?.name ?? null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            className="text-2xl font-bold"
            style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}
          >
            Noticias
          </h1>
          <p className="text-sm mt-1" style={{ color: "#8a8070" }}>
            Gestiona todas las noticias del sitio
          </p>
        </div>
        <Button
          asChild
          className="text-white gap-2 font-semibold shadow-md hover:opacity-90"
          style={{ background: "linear-gradient(135deg, #C8102E, #a00d24)" }}
        >
          <Link to="/admin/posts/new">
            <Plus className="w-4 h-4" />
            Nueva noticia
          </Link>
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: "#8a8070" }}
          />
          <Input
            placeholder="Buscar por título..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="pl-9 border focus:ring-0"
            style={{
              background: "#ffffff",
              borderColor: "#ddd8d0",
              color: "#1E3A5F",
            }}
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setStatusFilter(v);
            setPage(1);
          }}
        >
          <SelectTrigger
            className="w-full sm:w-44 border"
            style={{ background: "#ffffff", borderColor: "#ddd8d0", color: "#1E3A5F" }}
          >
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent style={{ background: "#ffffff", border: "1px solid #ddd8d0" }}>
            <SelectItem value="all" style={{ color: "#1E3A5F" }}>
              Todos
            </SelectItem>
            <SelectItem value="published" style={{ color: "#1E3A5F" }}>
              Publicados
            </SelectItem>
            <SelectItem value="draft" style={{ color: "#1E3A5F" }}>
              Borradores
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div
        className="rounded-2xl overflow-hidden shadow-sm"
        style={{ background: "#ffffff", border: "1px solid #e5e0d8" }}
      >
        <Table>
          <TableHeader>
            <TableRow
              style={{ background: "#1E3A5F", borderBottom: "2px solid #E8B830" }}
            >
              <TableHead className="text-white font-semibold text-xs uppercase tracking-wide">
                Título
              </TableHead>
              <TableHead className="text-white font-semibold text-xs uppercase tracking-wide hidden md:table-cell">
                Categoría
              </TableHead>
              <TableHead className="text-white font-semibold text-xs uppercase tracking-wide hidden sm:table-cell">
                Estado
              </TableHead>
              <TableHead className="text-white font-semibold text-xs uppercase tracking-wide hidden lg:table-cell">
                Fecha
              </TableHead>
              <TableHead className="text-white font-semibold text-xs uppercase tracking-wide text-right">
                Acciones
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i} style={{ borderBottom: "1px solid #f0ece4" }}>
                  <TableCell>
                    <Skeleton className="h-4 w-3/4" style={{ background: "#e5e0d8" }} />
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <Skeleton className="h-4 w-20" style={{ background: "#e5e0d8" }} />
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <Skeleton className="h-5 w-16" style={{ background: "#e5e0d8" }} />
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">
                    <Skeleton className="h-4 w-24" style={{ background: "#e5e0d8" }} />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-8 w-20 ml-auto" style={{ background: "#e5e0d8" }} />
                  </TableCell>
                </TableRow>
              ))
            ) : posts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="py-16 text-center">
                  <div
                    className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: "#f5f3ef" }}
                  >
                    <Newspaper className="w-8 h-8" style={{ color: "#c4bdb0" }} />
                  </div>
                  <p className="text-sm font-medium" style={{ color: "#8a8070" }}>
                    {search || statusFilter !== "all"
                      ? "No se encontraron noticias con esos filtros."
                      : "No hay noticias aún."}
                  </p>
                  {!search && statusFilter === "all" && (
                    <Button
                      asChild
                      size="sm"
                      className="mt-4 text-white gap-1"
                      style={{ background: "#1E3A5F" }}
                    >
                      <Link to="/admin/posts/new">
                        <Plus className="w-3 h-3" />
                        Crear primera noticia
                      </Link>
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ) : (
              posts.map((post) => {
                const catName = getCategoryName(
                  post.categoryId ? Number(post.categoryId) : null
                );
                return (
                  <TableRow
                    key={post.id}
                    className="transition-colors group"
                    style={{ borderBottom: "1px solid #f0ece4" }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.background = "#faf8f5";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.background = "transparent";
                    }}
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        {/* Status accent dot */}
                        <div
                          className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{
                            background:
                              post.status === "published" ? "#2e7d32" : "#E8B830",
                          }}
                        />
                        <div className="min-w-0">
                          <p
                            className="text-sm font-semibold line-clamp-1"
                            style={{ color: "#1E3A5F" }}
                          >
                            {post.title}
                          </p>
                          <p
                            className="text-xs mt-0.5 line-clamp-1 hidden sm:block"
                            style={{ color: "#8a8070" }}
                          >
                            /{post.slug}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {catName ? (
                        <span
                          className="text-xs font-medium px-2.5 py-1 rounded-full"
                          style={{
                            background: "rgba(30,58,95,0.08)",
                            color: "#1E3A5F",
                          }}
                        >
                          {catName}
                        </span>
                      ) : (
                        <span style={{ color: "#c4bdb0" }}>—</span>
                      )}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <span
                        className="text-xs font-medium px-2.5 py-1 rounded-full inline-flex items-center gap-1"
                        style={
                          post.status === "published"
                            ? { background: "rgba(46,125,50,0.1)", color: "#2e7d32" }
                            : { background: "rgba(232,184,48,0.15)", color: "#b8920a" }
                        }
                      >
                        {post.status === "published" ? (
                          <>
                            <Globe className="w-2.5 h-2.5" />
                            Publicado
                          </>
                        ) : (
                          <>
                            <FileText className="w-2.5 h-2.5" />
                            Borrador
                          </>
                        )}
                      </span>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <span className="text-xs" style={{ color: "#8a8070" }}>
                        {format(new Date(post.createdAt), "d MMM yyyy", {
                          locale: es,
                        })}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          asChild
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 transition-colors"
                          style={{ color: "#8a8070" }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLElement).style.color = "#1E3A5F";
                            (e.currentTarget as HTMLElement).style.background = "rgba(30,58,95,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLElement).style.color = "#8a8070";
                            (e.currentTarget as HTMLElement).style.background = "transparent";
                          }}
                        >
                          <Link to={`/admin/posts/${post.id}/edit`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 transition-colors"
                          style={{ color: "#8a8070" }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLElement).style.color = "#C8102E";
                            (e.currentTarget as HTMLElement).style.background =
                              "rgba(200,16,46,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLElement).style.color = "#8a8070";
                            (e.currentTarget as HTMLElement).style.background = "transparent";
                          }}
                          onClick={() => setDeleteId(post.id)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-xs" style={{ color: "#8a8070" }}>
            Mostrando {(page - 1) * 10 + 1}–
            {Math.min(page * 10, pagination.total)} de {pagination.total}
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              className="w-8 h-8 transition-colors"
              style={{ borderColor: "#ddd8d0", color: "#1E3A5F" }}
              disabled={page === 1}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="w-8 h-8 transition-colors"
              style={{ borderColor: "#ddd8d0", color: "#1E3A5F" }}
              disabled={page === pagination.totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Delete confirmation dialog */}
      <AlertDialog
        open={deleteId !== null}
        onOpenChange={(open) => !open && setDeleteId(null)}
      >
        <AlertDialogContent
          style={{ background: "#ffffff", border: "1px solid #e5e0d8", borderRadius: "1rem" }}
        >
          <AlertDialogHeader>
            <AlertDialogTitle style={{ color: "#1E3A5F", fontFamily: "'Playfair Display', serif" }}>
              ¿Eliminar esta noticia?
            </AlertDialogTitle>
            <AlertDialogDescription style={{ color: "#8a8070" }}>
              Esta acción no se puede deshacer. La noticia será eliminada
              permanentemente del sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="border transition-colors"
              style={{ borderColor: "#ddd8d0", color: "#1E3A5F", background: "#f5f3ef" }}
            >
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              className="text-white font-semibold transition-opacity hover:opacity-90"
              style={{ background: "#C8102E" }}
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Eliminando..." : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
